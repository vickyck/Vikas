export var button = document.querySelector("#myButton");
export var h3 = document.querySelector("h3");
