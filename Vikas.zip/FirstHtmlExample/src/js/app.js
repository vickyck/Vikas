import { button, h3 } from './fetchSelectors'
var toggleFlag = false;

function manageToggle() {
    if (toggleFlag) {
        h3.style.display = "block";
    }
    else {
        h3.style.display = "none";
    }
}

button.addEventListener("click", handleCLick)
manageToggle();

function handleCLick(){
    toggleFlag = !toggleFlag;
    manageToggle();
}