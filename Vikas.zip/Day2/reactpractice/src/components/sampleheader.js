import React, {Component} from 'react';

// export class SampleHeader extends Component {
//     render() {
//         return (
//             <div>
//                 sample header
//             </div>
//         )
//     }
// };

export const SampleHeader = (props) => (
    <nav className="navbar navbar-default">
        <div className="container-fluid">
            <ul className="nav navbar-nav">
                <li className="active">
                   <a href="/"> {props.headerLinkName}</a>
                </li>
            </ul>
        </div>
    </nav>
);