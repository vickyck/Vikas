import React, { Component } from 'react';
import './App.css';

import {BrowserRouter as Router, Route, Link} from 'react-router-dom';

import {Home} from './home';

const App = () => (
    <Router>
        <div className="App">
            <div>
                <ul>
                    <li>
                        <Link to="/">Home</Link>
                    </li>
                    <li>
                        <Link to="/about">About</Link>
                    </li>
                    <li>
                        <Link to="/topics">Topics</Link>
                    </li>
                </ul>
            </div>
        <br/>
        <Route exact path="/" component={Home}></Route>
        <Route path="/about" component={About}></Route>
        <Route path="/topics" component={Topics}></Route>
        </div>
    </Router>
)

const About = () => (
    <div>
        <h3>This is About</h3>
    </div>
)

const Topic = ({match}) => {
    <h2>You have selected {match.params.parmId}</h2>
}

const Render = ({match}) => {
    <h2>You have selected {match.params.parmId}</h2>
}

const LifeCycle = ({match}) => {
    <h2>You have selected {match.params.parmId}</h2>
}

const PropsVsState = ({match}) => {
    <h2>You have selected {match.params.parmId}</h2>
}

const Topics = ({match}) => (
    <div>
        <h3>This is page Topics</h3>
            <div>
                <ul>
                    <li>
                        <Link to={`${match.url}/render`}>Rendering</Link>
                    </li>
                    <li>
                        <Link to={`${match.url}/lifecyclem`}>Life cycle methods</Link>
                    </li>
                    <li>
                        <Link to={`${match.url}/propsvsstate`}>Props Vs Sate</Link>
                    </li>
                </ul>
            </div>
        <Route path="/render" component={Render}></Route>
        <Route path="/lifecyclem" component={LifeCycle}></Route>
        <Route path="/propsvsstate" component={PropsVsState}></Route>
    </div>
)

export default App;

