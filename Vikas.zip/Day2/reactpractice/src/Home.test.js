import React from './react';
import { shallow } from 'enzyme';

import {Home} from './Home';

const props = {
    name: "Vikas"
}

it('renders the element', () =>{
    const element = shallow(<Home {...props}/>);
    expect(element).toBeTrue();
})