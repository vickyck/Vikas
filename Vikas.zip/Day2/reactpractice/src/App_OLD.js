import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

import { SampleHeader } from './components/sampleheader';
import { Home } from './components/home';

import {BrowserRouter as Router, Route, Link} from 'react-router-dom';

class AppOld extends Component {

  constructor(props) {
    super(props);

    this.state = {
      headerLink: "Home",
      showHome: true
    }
  }

  handleClick() {
    debugger;
  }

  SayHello() {
    alert("Hello");
  }

  takeValue(myVal){
    this.setState({
      headerLink: myVal
    });
  }

  render() {
    let user = {
      nationality: "Indian",
      hobbies: [1,2,3,4,5,6]
    }
    let home = '';
    if (this.state.showHome) {
      home = (
        <Home 
            name="Vikas" 
            age={32} 
            user={user} 
            triggerHello={() => this.SayHello()}
            sendAValue={this.takeValue.bind(this)}
            headerLinkName={this.state.headerLink}
            >
            <p>This is a paragraph</p>
          </Home>
      );
    }

    return (
      // <div className="container">
      //     <div className="row">
      //       <SampleHeader headerLinkName={this.state.headerLink}/>
      //     </div>
      //     <div className="row">
      //       <Home 
      //         name="Vikas" 
      //         age={32} 
      //         user={user} 
      //         triggerHello={() => this.SayHello()}
      //         sendAValue={this.takeValue.bind(this)}
      //         headerLinkName={this.state.headerLink}
      //         >
      //         <p>This is a paragraph</p>
      //       </Home>
      //     </div>
      // </div>
        <div className="App">
          <input type="text" ref="ref1" name="name1"/>
          <button onClick={() => this.handleClick()}>
            Hit me
          </button>
        </div>
    );
  }
}

export default AppOld;
