import React, {Component} from "react";

export class PropertyChild extends Component {
    render() {
        return(
            <div>
                <h5>Name is {this.props.name} and Located at {this.props.location}</h5>
            </div>
        )
    }
}