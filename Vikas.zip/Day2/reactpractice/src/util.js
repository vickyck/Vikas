export const makeApi = (url) => {
    return fetch(url)
    .then((data) => data.json())
    .then((response) => {
        this.setState({
            name: response.name,
            location: response.location
        })
    });
}

export const makePostCall = (url, payload, headers) => {
    return fetch(url, {method: 'POST', headers: headers, data: payload})
    .then((data) => data.json())
    .then((response) => {
        this.setState({
            name: response.name,
            location: response.location
        })
    });
}