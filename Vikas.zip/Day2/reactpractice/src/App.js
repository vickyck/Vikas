import React, {Component} from "react";

import { PropertyChild } from './propertychild';

export class App extends Component{
    constructor(props){
        super(props);

        this.state = {
            name: "",
            location: ""
        }
    }

    componentDidMount() {
        var url = "https://api.github.com/users/harzz";
        fetch(url)
        .then((data) => data.json())
        .then((response) => {
            this.setState({
                name: response.name,
                location: response.location
            })
        })
    };

    render() {
        return (
            <div>
                <h3>This is Home component and git id is {this.props.name}</h3>
                <PropertyChild name={this.state.name} location={this.state.location}>
                </PropertyChild>
            </div>
        )
    }
}

export default App;


