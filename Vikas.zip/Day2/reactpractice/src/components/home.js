import React, {Component} from 'react';

export class Home extends Component{
    constructor(props){
        super(props);
        this.state = {
            homeAge: props.age,
            inputValue: props.headerLinkName
        }
        console.log("constructor");
    }

    componentWillCount(){
        console.log("Component will mount");
    }

    componentDidMount(){
        // Api calls
        console.log("component did mount");
    }

    componentWillReceiveProps(newProps){
        console.log(newProps);
        console.log("componentwillreceiveprops");
    }

    shouldComponentUpdate(props, state) {
        console.log(props);
        console.log(state);
        console.log("shouldComponentUpdate");

        // if (state.status === 1){
        //     return false;
        // }
        return true;
    }

    componentWillUpdate(){
        console.log("componentWillUpdate");
    }

    componentDidUpdate(){
        console.log("componentDidUpdate");
    }

    componentWillUnmount(){
        console.log("componentWillUnmount");
    }

    handleAge() {
        this.setState({
            homeAge: this.state.homeAge + 3
        })
    }

    handleClick(){
        this.props.sendAValue(this.state.inputValue);
    }

    handleInputChange(e){
        this.setState({
            inputValue: e.target.value
        });
        this.props.sendAValue(this.state.inputValue);
    }

    render() {
        console.log(this.props)
        return (
            <div className="row">
                <div className="col-sm-12">
                    {this.props.name} and my age is {this.state.homeAge}
                    {this.props.children}
                </div>
                <div className="col-sm-12">
                    <button className="btn btn-primary" onClick={this.handleAge.bind(this)}>
                        Increase age
                    </button>&nbsp;

                    <button className="btn btn-danger" onClick={this.props.triggerHello}>Say Hello</button>
                    <button className="btn btn-warning" onClick={() => this.handleClick()}>Send Value</button>
                </div>

                <div className="col-sm-12">
                    <input type="text" 
                           value={this.state.inputValue} 
                           onChange={this.handleInputChange.bind(this)}/>
                </div>
            </div>
        )
    }
};